
/**
 *Name: AbdielNie
 *date: 09/29/2017
 *description: 3 – 01 Using String/Scanner Exercises  question 1
 */
public class Question1
{
    public static void main (String [] args)
    {
        String a = "String";
        String b = "Code";
        String c = "Practice";
        System.out.println(a.substring(2,4));
        System.out.println(b.substring(1,3));
        System.out.println(c.substring(3,5));
    }
   
}
