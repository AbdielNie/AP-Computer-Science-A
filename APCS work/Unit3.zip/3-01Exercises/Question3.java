import java.util.Scanner;
/**
 * name: AbdielNie
 * date:09/29/2017
 * description:Question 3
 */
public class Question3
{
    public static void main (String [] args)
    {
        String a = "Hi";
        String b = "Bye";
        
        
        String concatenate = a + b + b + a;
        System.out.println (concatenate);
    }
}
