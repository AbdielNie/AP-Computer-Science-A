
/**
 * Trying oujt Math Class Operations
 */
public class MathClassTesting
{
   public static void main (String [] args)
   {
       int first = 37;
       int second = 52;
       
       System.out.println (Math.max(first,second));
       System.out.println (Math.pow(2,3));//8
       System.out.println (Math.abs(-123456));//postive
       System.out.println (Math.min(first,second));
    // Math.pow(double base, double exp);
    // Math.abs(int/double number);
    // Math.min(int/double.int/double);
    }
}
