Calculator
====================
![](https://github.com/laserwave/Calculator/blob/master/images/fx-Calc.png)

三角函数使用弧度制单位。

界面设计参考eCalc。

Author
======

 * ZhikaiZhang 
 * Email <zhangzhikai@seu.edu.cn>
 * Blog <http://zhikaizhang.cn>
 * [javafx实现简易计算器](http://zhikaizhang.cn/2016/10/07/javafx%E5%AE%9E%E7%8E%B0%E7%AE%80%E6%98%93%E8%AE%A1%E7%AE%97%E5%99%A8/)
 * [从简易计算器到科学计算器](http://zhikaizhang.cn/2016/11/02/%E4%BB%8E%E7%AE%80%E6%98%93%E8%AE%A1%E7%AE%97%E5%99%A8%E5%88%B0%E7%A7%91%E5%AD%A6%E8%AE%A1%E7%AE%97%E5%99%A8/)

License
=======

    Copyright 2016 ZhikaiZhang 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.

