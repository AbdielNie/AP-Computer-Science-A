package cn.zhikaizhang.algorithm;

public class ExpressionIllegalException extends Exception {

    public ExpressionIllegalException() {
        super();
    }
}