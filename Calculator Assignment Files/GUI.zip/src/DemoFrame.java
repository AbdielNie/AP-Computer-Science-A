import javax.swing.*;

/**
 * Name: Mr. Lee
 * Date: 2016-05-16
 * Program Name:
 * Description:
 */
public class DemoFrame {
    public static void main(String[] args) {
        JFrame frame = new JFrame(); //creating a new frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //setting it such that when the window closes, program ends
        frame.setVisible(true);//setting the frame to be visible
    }
}
