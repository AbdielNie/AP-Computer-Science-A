import javax.swing.*;

/**
 * Name: Mr. Lee
 * Date: 2016-05-16
 * Program Name:
 * Description:
 */
public class DemoFrame2 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Title of Frame"); //different constructor, now with a title
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
