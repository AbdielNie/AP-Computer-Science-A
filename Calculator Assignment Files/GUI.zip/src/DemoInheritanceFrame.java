import javax.swing.*;
import java.awt.*;

/**
 * Name: Mr. Lee
 * Date: 2016-05-16
 * Program Name:
 * Description:
 */
public class DemoInheritanceFrame extends JFrame{
    public DemoInheritanceFrame(){
        super();
        this.setSize(300,300);
        this.setTitle("This is a new Title");
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);



        JLabel label = new JLabel("Hello World!"); //creating a label
        this.setLayout(new FlowLayout());



        JTextField text = new JTextField(10);
        JPasswordField pass = new JPasswordField(10);
        JFormattedTextField format = new JFormattedTextField("SDKJFKDLSJLJSLKF");

        this.add(label);//adding it to this frame
        this.add(text);
        this.add(pass);
        this.add(format);
    }

    public static void main(String[] args) {
        JFrame myFrame = new DemoInheritanceFrame();
        myFrame.setVisible(true);
    }
}
