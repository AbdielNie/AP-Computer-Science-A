import javax.swing.*;
import java.awt.*;

/**
 * Name: Mr. Lee
 * Date: 2016-05-16
 * Program Name:
 * Description:
 */
public class DemoJText {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setSize(300,300);
        frame.setTitle("This is a new Title");
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);



        JLabel label = new JLabel("Hello World!"); //creating a label
        frame.setLayout(new FlowLayout());



        JTextField text = new JTextField(10);
        JPasswordField pass = new JPasswordField(10);
        JFormattedTextField format = new JFormattedTextField("SDKJFKDLSJLJSLKF");

        frame.add(label);//adding it to the frame
        frame.add(text);
        frame.add(pass);
        frame.add(format);

        frame.setVisible(true);
    }
}
