import javax.swing.*;
import java.awt.*;
import java.net.URL;

/**
 * Name: Mr. Lee
 * Date: 2016-05-17
 * Program Name:
 * Description:
 */
public class DemoJMenu {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setSize(400,400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JMenuBar mainMenuBar;// menu bar
        JMenu menu1, menu2, submenu; //drop down menus
        JMenuItem plainTextMenuItem, textIconMenuItem, iconMenuItem, subMenuItem; //text items
        JRadioButtonMenuItem rbMenuItem; //radio button items
        JCheckBoxMenuItem cbMenuItem; // check box items
        ImageIcon icon = new ImageIcon("src/jmenu.jpg"); //image

        mainMenuBar = new JMenuBar();

        menu1 = new JMenu("Menu 1");

        //Creating the MenuItems
        plainTextMenuItem = new JMenuItem("Menu item with Plain Text");
        menu1.add(plainTextMenuItem);


        textIconMenuItem = new JMenuItem("Menu Item with Text & Image", icon);
        menu1.add(textIconMenuItem);

        //Menu Item with just an Image
        iconMenuItem = new JMenuItem(icon);
        menu1.add(iconMenuItem);

        menu1.addSeparator();
        //Radio Button Menu items follow a seperator

        ButtonGroup itemGroup = new ButtonGroup();

        rbMenuItem = new JRadioButtonMenuItem("Menu Item with Radio Button");
        itemGroup.add(rbMenuItem);
        menu1.add(rbMenuItem);

        rbMenuItem = new JRadioButtonMenuItem("Menu Item 2 with Radio Button");
        itemGroup.add(rbMenuItem);
        menu1.add(rbMenuItem);

        menu1.addSeparator();
        //Radio Button Menu items follow a seperator
        cbMenuItem = new JCheckBoxMenuItem("Menu Item with check box");
        menu1.add(cbMenuItem);

        cbMenuItem = new JCheckBoxMenuItem("Menu Item 2 with check box");
        menu1.add(cbMenuItem);

        menu1.addSeparator();
        //Sub Menu follows a seperator
        submenu = new JMenu("Sub Menu");
        subMenuItem = new JMenuItem("Sub MenuItem 1");
        submenu.add(subMenuItem);

        subMenuItem = new JMenuItem("Sub MenuItem 2");
        submenu.add(subMenuItem);


        menu1.add(submenu);
        mainMenuBar.add(menu1);

        //Build second menu in the menu bar.
        menu2 = new JMenu("Menu 2");
        mainMenuBar.add(menu2);

        frame.add(mainMenuBar, BorderLayout.NORTH);
        frame.add(new JTextField("Main Text Here"), BorderLayout.CENTER);
        frame.setVisible(true);
    }
}
