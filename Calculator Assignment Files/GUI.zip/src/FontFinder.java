import java.awt.*;

/**
 * Name: Mr. Lee
 * Date: 2016-05-17
 * Program Name:
 * Description:
 */
public class FontFinder {
    public static void main(String[] args) {
        GraphicsEnvironment e = GraphicsEnvironment.getLocalGraphicsEnvironment();
        String[] fontnames = e.getAvailableFontFamilyNames();
        for (int i = 0; i < fontnames.length; i++)
            System.out.println(fontnames[i]);
    }

}
