import javax.swing.*;
import java.awt.*;

/**
 * Name: Mr. Lee
 * Date: 2016-05-17
 * Program Name:
 * Description:
 */
public class DemoFont {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setSize(300,300);
        frame.setTitle("This is a new Title");
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton button = new JButton("Ok");
        Font myFont = new Font("Serif",Font.BOLD,50);//creating a font
        button.setFont(myFont);//setting the font of the button
        frame.add(button);

        frame.setVisible(true);
    }
}
