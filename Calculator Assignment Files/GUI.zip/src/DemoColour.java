import javax.swing.*;
import java.awt.*;

/**
 * Name: Mr. Lee
 * Date: 2016-05-17
 * Program Name:
 * Description:
 */
public class DemoColour {

    final public static Color WESTERN_PURPLE = new Color(79,38,131); //declaring a constant

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setSize(300,300);
        frame.setTitle("This is a new Title");
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton button = new JButton("Ok");

        Color c = new Color (255,255,0); //create a new colour: purple
        button.setBackground(c); //set the background to be purple
        button.setForeground(Color.RED); //set the text to be red

        //button.setBackground(DemoColour.WESTERN_PURPLE); demonstrating using a static constant of a class

        frame.add(button);


        frame.setVisible(true);
    }
}
