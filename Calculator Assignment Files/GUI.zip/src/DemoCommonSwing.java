import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;

/**
 * Name: Mr. Lee
 * Date: 2016-05-17
 * Program Name:
 * Description:
 */
public class DemoCommonSwing extends JFrame {
    public DemoCommonSwing(){
        //Create a panel to group three buttons
        JPanel p1 = new JPanel(new FlowLayout(FlowLayout.LEFT,2,2));
        JButton jbtLeft = new JButton("Left");
        JButton jbtCenter = new JButton("Center");
        JButton jbtRight = new JButton("Right");
        jbtLeft.setBackground(Color.WHITE);
        jbtCenter.setForeground(Color.GREEN);
        jbtRight.setToolTipText("This is the Right button");
        p1.add(jbtLeft);
        p1.add(jbtCenter);
        p1.add(jbtRight);
        p1.setBorder(new TitledBorder("Three Buttons"));
        p1.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));

        //create a font and a line border
        Font largeFont = new Font("Serif",Font.BOLD,20);
        LineBorder lineBorder = new LineBorder(Color.BLACK,2);

        //create a panel to group two labels
        JPanel p2 = new JPanel (new GridLayout(1,2,5,5));
        JLabel jlbRed = new JLabel("Red");
        JLabel jlbOrange = new JLabel("Orange");
        jlbRed.setForeground(Color.RED);
        jlbRed.setFont(largeFont);
        jlbRed.setBorder(lineBorder);
        jlbOrange.setForeground(Color.ORANGE);
        jlbOrange.setFont(largeFont);
        jlbOrange.setBorder(lineBorder);
        p2.add(jlbRed);
        p2.add(jlbOrange);

        //add labels to the frame
        this.setLayout(new GridLayout(2,1,5,5));
        add(p1);
        add(p2);
    }

    public static void main(String[] args) {
        JFrame frame = new DemoCommonSwing();
        frame.setTitle("Test Swing Common Features");
        frame.setSize(300,150);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
