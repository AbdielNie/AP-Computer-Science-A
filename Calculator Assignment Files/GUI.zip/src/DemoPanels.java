import javax.swing.*;
import java.awt.*;

/**
 * Name: Mr. Lee
 * Date: 2016-05-16
 * Program Name:
 * Description:
 */
public class DemoPanels {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setSize(400,250);
        frame.setTitle("Microwave");
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        JPanel p1 = new JPanel(); //panel, a container with a specific layout
        p1.setLayout(new GridLayout(4,3)); //setting the layout

        for (int i = 1; i <= 9; i++){
            p1.add(new JButton("" + i));
        }
        p1.add(new JButton("0"));
        p1.add(new JButton("Start"));
        p1.add(new JButton("Stop"));

        JPanel p2 = new JPanel(); //another panel
        p2.setLayout(new BorderLayout());
        JTextField t = new JTextField("Time to be displayed here");
        p2.add(t,BorderLayout.NORTH);
        p2.add(p1,BorderLayout.CENTER); //since panel is technically a component, we can put a panel inside a panel

        frame.add(new JButton("Food to be placed here!"),BorderLayout.WEST);
        frame.add(p2,BorderLayout.CENTER);

        frame.setVisible(true);
    }
}
