import javax.swing.*;

/**
 * Name: Mr. Lee
 * Date: 2016-05-16
 * Program Name:
 * Description:
 */
public class DemoJComponent {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setSize(300,300);
        frame.setTitle("This is a new Title");
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton button = new JButton("Ok");//create a button
        frame.add(button); //put it into frame

        /*JButton button2 = new JButton("Ok2");//create a button
        frame.add(button2); //put it into frame*/

        frame.setVisible(true);
    }
}
