import javax.swing.*;
import java.awt.*;

/**
 * Name: Mr. Lee
 * Date: 2016-05-16
 * Program Name:
 * Description:
 */
public class DemoFlowLayout {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setSize(300,300);
        frame.setTitle("This is a new Title");
        frame.setLocationRelativeTo(null);
        frame.setLayout(new FlowLayout()); //setting the layout to flowlayout
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton button = new JButton("Ok");
        frame.add(button);

        JButton button2 = new JButton("Ok2");
        frame.add(button2);

        frame.setVisible(true);
    }
}
