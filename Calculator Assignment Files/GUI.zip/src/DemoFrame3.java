import javax.swing.*;

/**
 * Name: Mr. Lee
 * Date: 2016-05-16
 * Program Name:
 * Description:
 */
public class DemoFrame3 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Title of Frame");
        frame.setSize(300,300); //setting the size of the frame (x, y)
        frame.setLocation(300,300);//setting the starting location of the frame (x, y)
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

    }
}
