import javax.swing.*;
import java.awt.*;

/**
 * Name: Mr. Lee
 * Date: 2016-05-17
 * Program Name:
 * Description:
 */
public class DemoImageIcon {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setSize(300,300);
        frame.setTitle("This is a new Title");
        frame.setLocationRelativeTo(null);
        frame.setLayout(new FlowLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        ImageIcon myIcon = new ImageIcon("src/jmenu.jpg"); //creating an Icon

        JButton button = new JButton(myIcon); //initialize with icon, before setting text
        button.setText("Ok");
        frame.add(button);

        JButton button2 = new JButton("Ok2"); //initialize with text, then setting icon
        button2.setIcon(myIcon);
        frame.add(button2);

        frame.setVisible(true);
    }
}
