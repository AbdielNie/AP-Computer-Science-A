
public class TryPictures
{
    public static void main (String [] args) {
        Picture myPicture = new Picture("myface.jpg");
        //myPicture.edgeDetection();
        myPicture.show();
        myPicture.obamaPic().show();
    }
}
