
/**
 * name:AbdielNie
 * description: demo of loop
 */
public class demoLoop
{
    public static void whileLoop()
    {
        int i = 1;
        while (i <= 10)
        {
            System.out.println(i);
            i++;
        }
    }
    public static void whileLoop2(int num)
    {       
        int i = 1;
        while (i <= num)
        {
        System.out.println(i);
        i++;
        }
    }
    public static void forLoop()
    {
        int i;
        for (i = 1; i <= 10; i++ )
        {
            System.out.println(i);
        }
    }
    public static void forLoop2(int num)
    {
        int i;
        for (i = 1; i <= num; i++)
        {
            System.out.println(i);
        }
    }
    
        
    
}
