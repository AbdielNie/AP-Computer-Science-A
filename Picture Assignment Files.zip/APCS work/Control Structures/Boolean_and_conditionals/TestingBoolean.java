
/**
 * Write a description of class TestingBoolean here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestingBoolean
{
    public static void testboolean()
    {
        boolean isOld = true;
        boolean isShuai = false;
        System.out.println(isOld);
    }
    public static void testboolean2()
    {
        boolean mStatement = 5 < 3;
        boolean tStatement = ((int)5.6 == 5);
        System.out.println(mStatement);
        System.out.println(tStatement);
    }
}
