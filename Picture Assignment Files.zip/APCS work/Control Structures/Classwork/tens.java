import java.util.Scanner;
/**
 * 在这里给出对类 tens 的描述。
 * 
 * @作者（你的名字）
 * @版本（一个版本号或者一个日期）
 */
public class tens
{
//    /* 
     public static void main(String [] args)
    {
        int t;
        int r;
        int c;
        Scanner tens = new Scanner(System.in);
        t = tens.nextInt();
        r = (int)t/10;
        c = r * 10;
        System.out.println(c);
        
    }
//    */

}
