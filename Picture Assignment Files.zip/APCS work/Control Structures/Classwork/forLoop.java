
public class forLoop
{
    /**
     * Given a number, return that many “*” as a string. 
     */
    public static String Num(String n)
    {
        char i;
        String str = "";
        for (i = 42; i >= n.length();)
            {
                str += i;
            }
            return str;
            

    }
    /**
     * Given a string, return true if the first instance of "x" 
     * in the string is immediately followed by another "x". 
     */
    //public static void returnX(String a)
    //{
    //    for(int i <= a.length();)
    //    {
            
            
    //    }
    //    }
}
    


