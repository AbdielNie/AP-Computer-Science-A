
/**
 *variable study
 *writer:Abdiel
 *version: 1.0
 */
public class Variable
{
public static void main (String [] args)
{
 final double PI = 3.1415926;
 double area;
 double radius;
 
 radius = 1.0;
 area = radius * radius * PI;
 
 System.out.println("The area is" + area + "for radius" +radius);
}
}
    