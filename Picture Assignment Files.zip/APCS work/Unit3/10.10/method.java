
/**
 * how to find add three integers together
 */
public class method
{
    // access modifier- who can use/acceess it
        //modifier- what is using it(objsects,or just code)
            //return type-what type  of data will result
                //method name/identifier- how to call the method
                    //formal parameters- variables to be used in the method
    public static int addThreeNumbers(int num1, int num2, int num3)
    {
        int returnValue = num1 + num2 + num3;
        return returnValue;
    }
    //example
    public class Person
    {
        private String name;
        private int height;
        private boolean inCool;
        //constructor
        
        //grow up
        public void growUp(int addHeight)
        {
            height += add Height;
            
        }
        public static static double calculateBMI(Person aPerson)
        {
        }
        public static boolean isOld(int age)
        {
        }
    }
}
